#!/usr/bin/env python3
"""
app.py — Local web app for Smartsheet checklist sync.

Run:
  export SMARTSHEET_API_TOKEN="your_token"
  python app.py

Then open http://localhost:5000 in your browser.
"""

import json
import os
import sys
import threading
from datetime import datetime
from typing import List, Optional

try:
    from flask import Flask, render_template, request, jsonify
except ImportError:
    print("ERROR: Flask is not installed.  pip install flask")
    sys.exit(1)

try:
    import smartsheet
except ImportError:
    print("ERROR: smartsheet-python-sdk is not installed.  pip install smartsheet-python-sdk")
    sys.exit(1)

from smartsheet_sync import (
    SheetPlan, get_workspace_layout, build_plans, apply_plan,
    plan_to_dict, key_of,
)


CONFIG_PATH = os.environ.get("CHECKLIST_SYNC_CONFIG", "config.json")
DEFAULT_CONFIG = {
    "workspace_id": None,
    "templates_folder_name": "Templates",
    "instance_columns": ["Check Status", "Signed Off By", "Date Completed", "Comments"],
    "key_column": None,
}


# ----- In-memory state (single-user local app) -----
_state_lock = threading.Lock()
_state = {
    "plans": [],            # type: List[SheetPlan]
    "scanned_at": None,     # type: Optional[datetime]
    "workspace_id": None,
}


app = Flask(__name__)


# ---------- helpers ----------

def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        return dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
        for k, v in DEFAULT_CONFIG.items():
            cfg.setdefault(k, v)
        return cfg
    except Exception:
        return dict(DEFAULT_CONFIG)


def save_config(cfg: dict) -> None:
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)


def get_client() -> Optional["smartsheet.Smartsheet"]:
    token = os.environ.get("SMARTSHEET_API_TOKEN")
    if not token:
        return None
    client = smartsheet.Smartsheet(token)
    client.errors_as_exceptions(True)
    return client


# ---------- routes ----------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    cfg = load_config()
    return jsonify({
        "token_set": bool(os.environ.get("SMARTSHEET_API_TOKEN")),
        "config": cfg,
        "last_scan": _state["scanned_at"].isoformat() if _state["scanned_at"] else None,
        "has_pending_plans": len(_state["plans"]) > 0,
    })


@app.route("/api/config", methods=["POST"])
def api_config():
    body = request.get_json(force=True)
    cfg = load_config()
    # Whitelist fields
    for k in ("workspace_id", "templates_folder_name", "instance_columns", "key_column"):
        if k in body:
            cfg[k] = body[k]
    # Normalise
    if cfg.get("workspace_id") in ("", None):
        cfg["workspace_id"] = None
    else:
        try:
            cfg["workspace_id"] = int(cfg["workspace_id"])
        except (TypeError, ValueError):
            return jsonify({"error": "workspace_id must be a number"}), 400
    if cfg.get("key_column") == "":
        cfg["key_column"] = None
    if not cfg.get("templates_folder_name"):
        cfg["templates_folder_name"] = "Templates"
    if not isinstance(cfg.get("instance_columns"), list):
        cfg["instance_columns"] = []
    cfg["instance_columns"] = [c.strip() for c in cfg["instance_columns"] if c and c.strip()]

    save_config(cfg)
    return jsonify({"ok": True, "config": cfg})


@app.route("/api/scan", methods=["POST"])
def api_scan():
    client = get_client()
    if client is None:
        return jsonify({"error": "SMARTSHEET_API_TOKEN environment variable is not set."}), 400

    cfg = load_config()
    if not cfg.get("workspace_id"):
        return jsonify({"error": "Workspace ID is not configured. Save your settings first."}), 400

    body = request.get_json(silent=True) or {}
    allow_empty = bool(body.get("allow_empty_master", False))

    try:
        template_sheets, generators = get_workspace_layout(
            client, cfg["workspace_id"], cfg.get("templates_folder_name", "Templates"),
        )
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 400
    except smartsheet.exceptions.ApiError as e:
        return jsonify({"error": f"Smartsheet API error: {e}"}), 400

    try:
        plans, warnings = build_plans(
            client, template_sheets, generators,
            cfg.get("instance_columns", []),
            cfg.get("key_column") or None,
            allow_empty,
        )
    except smartsheet.exceptions.ApiError as e:
        return jsonify({"error": f"Smartsheet API error: {e}"}), 400

    with _state_lock:
        _state["plans"] = plans
        _state["scanned_at"] = datetime.utcnow()
        _state["workspace_id"] = cfg["workspace_id"]

    serialised = [plan_to_dict(p, i) for i, p in enumerate(plans)]
    return jsonify({
        "summary": {
            "master_count": len(template_sheets),
            "generator_count": len(generators),
            "total_adds": sum(len(p.rows_to_add) for p in plans),
            "total_updates": sum(len(p.rows_to_update) for p in plans),
            "total_deletes": sum(len(p.rows_to_delete) for p in plans),
            "sheet_count": len(plans),
        },
        "generator_folders": [name for name, _ in generators],
        "plans": serialised,
        "warnings": warnings,
        "scanned_at": _state["scanned_at"].isoformat(),
    })


@app.route("/api/apply", methods=["POST"])
def api_apply():
    client = get_client()
    if client is None:
        return jsonify({"error": "SMARTSHEET_API_TOKEN environment variable is not set."}), 400

    body = request.get_json(silent=True) or {}
    selected_ids = body.get("plan_ids")  # None => all

    with _state_lock:
        plans = list(_state["plans"])

    if not plans:
        return jsonify({"error": "No plans cached. Run a scan first."}), 400

    results = []
    succeeded_ids = []
    for i, plan in enumerate(plans):
        if selected_ids is not None and i not in selected_ids:
            continue
        try:
            apply_plan(client, plan)
            results.append({
                "id": i,
                "ok": True,
                "label": f"{plan.generator_folder} / {'/'.join(plan.generator.rel_path)}",
            })
            succeeded_ids.append(i)
        except Exception as e:
            results.append({
                "id": i,
                "ok": False,
                "error": str(e),
                "label": f"{plan.generator_folder} / {'/'.join(plan.generator.rel_path)}",
            })

    # Drop successful plans from cache so they can't be re-applied
    with _state_lock:
        _state["plans"] = [p for i, p in enumerate(_state["plans"]) if i not in succeeded_ids]

    return jsonify({"results": results})


@app.route("/api/clear", methods=["POST"])
def api_clear():
    with _state_lock:
        _state["plans"] = []
        _state["scanned_at"] = None
    return jsonify({"ok": True})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    host = os.environ.get("HOST", "127.0.0.1")
    print(f"\nChecklist Sync running at http://{host}:{port}/\n")
    if not os.environ.get("SMARTSHEET_API_TOKEN"):
        print("WARNING: SMARTSHEET_API_TOKEN is not set. The UI will load but scans will fail.")
        print("Set it with:  export SMARTSHEET_API_TOKEN=\"your_token\"\n")
    app.run(host=host, port=port, debug=False)
