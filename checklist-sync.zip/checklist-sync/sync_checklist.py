#!/usr/bin/env python3
"""
sync_checklist.py — CLI for syncing checklist sheets. Wraps smartsheet_sync.py.

Usage:
  export SMARTSHEET_API_TOKEN="your_token"
  python sync_checklist.py                # dry-run preview
  python sync_checklist.py --apply        # apply after confirmation
  python sync_checklist.py --apply --yes  # apply without prompting
"""

import argparse
import json
import os
import sys

try:
    import smartsheet
except ImportError:
    print("ERROR: smartsheet-python-sdk is not installed.  pip install smartsheet-python-sdk")
    sys.exit(1)

from smartsheet_sync import (
    get_workspace_layout, build_plans, apply_plan, key_of,
)


def load_config(path: str) -> dict:
    if not os.path.exists(path):
        print(f"ERROR: Config file not found: {path}. Copy config.example.json to config.json.")
        sys.exit(1)
    with open(path) as f:
        return json.load(f)


def load_token() -> str:
    token = os.environ.get("SMARTSHEET_API_TOKEN")
    if not token:
        print("ERROR: Set SMARTSHEET_API_TOKEN environment variable.")
        sys.exit(1)
    return token


def print_preview(plans):
    adds = updates = deletes = 0
    for p in plans:
        adds += len(p.rows_to_add)
        updates += len(p.rows_to_update)
        deletes += len(p.rows_to_delete)
        print(f"\n[{p.generator_folder}] {'/'.join(p.generator.rel_path)}")
        if p.rows_to_add:
            print(f"  + Add {len(p.rows_to_add)} row(s):")
            for r in p.rows_to_add[:5]:
                print(f"      + {key_of(r, p.key_column) or '(no key)'}")
            if len(p.rows_to_add) > 5:
                print(f"      ... and {len(p.rows_to_add) - 5} more")
        if p.rows_to_update:
            print(f"  ~ Update {len(p.rows_to_update)} row(s):")
            for _, src in p.rows_to_update[:5]:
                print(f"      ~ {key_of(src, p.key_column) or '(no key)'}")
            if len(p.rows_to_update) > 5:
                print(f"      ... and {len(p.rows_to_update) - 5} more")
        if p.rows_to_delete:
            print(f"  - Delete {len(p.rows_to_delete)} row(s):")
            for r in p.rows_to_delete[:5]:
                print(f"      - {key_of(r, p.key_column) or '(no key)'}")
            if len(p.rows_to_delete) > 5:
                print(f"      ... and {len(p.rows_to_delete) - 5} more")
    return adds, updates, deletes


def main():
    ap = argparse.ArgumentParser(description="Sync checklist rows from master templates to generator copies.")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--allow-empty-master", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    token = load_token()

    client = smartsheet.Smartsheet(token)
    client.errors_as_exceptions(True)

    print(f"Reading workspace {cfg['workspace_id']}...")
    template_sheets, generators = get_workspace_layout(
        client, cfg["workspace_id"], cfg.get("templates_folder_name", "Templates"),
    )
    print(f"  Master sheets: {len(template_sheets)}")
    print(f"  Generator folders: {len(generators)} -> {', '.join(n for n, _ in generators)}")

    plans, warnings = build_plans(
        client, template_sheets, generators,
        cfg.get("instance_columns", []),
        cfg.get("key_column") or None,
        args.allow_empty_master,
    )

    for w in warnings:
        print(f"  NOTE: {w}")

    print("\n" + "=" * 72)
    print("DRY RUN PREVIEW")
    print("=" * 72)

    if not plans:
        print("Nothing to do. All generator sheets are in sync.")
        return

    adds, updates, deletes = print_preview(plans)
    print("\n" + "-" * 72)
    print(f"TOTAL: +{adds} adds, ~{updates} updates, -{deletes} deletes across {len(plans)} sheet(s)")
    print("-" * 72)

    if not args.apply:
        print("\nDry-run only. Re-run with --apply to execute.")
        return
    if not args.yes:
        if input("\nApply these changes? Type 'yes' to confirm: ").strip().lower() != "yes":
            print("Aborted.")
            return

    print("\nApplying...")
    for p in plans:
        print(f"  Syncing [{p.generator_folder}] {'/'.join(p.generator.rel_path)}...")
        apply_plan(client, p)
    print("\nDone.")


if __name__ == "__main__":
    main()
